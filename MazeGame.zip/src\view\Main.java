package view;
import model.MazeGenerator;

public class Main {

}
